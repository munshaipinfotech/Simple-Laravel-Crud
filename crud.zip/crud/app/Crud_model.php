<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Crud_model extends Model
{
    protected $table='cruds';
    protected $primaryKey='id';
    protected $fillable=['name','location'];
}
