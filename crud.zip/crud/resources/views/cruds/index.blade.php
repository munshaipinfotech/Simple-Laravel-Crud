@extends('cruds.master')
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb" style="margin-top: 20px;">
            <div class="pull-left">
                <h2>Laravel 5.7 CRUD Test</h2>
            </div>
            <div class="pull-right">
                <a href="{{route('cruds.create')}}" class="btn btn-success">Create New Record</a>
            </div>
        </div>
    </div>
    @if($message=Session::get('success'))
        <div class="alert alert-success">
            <p>{{$message}}</p>
        </div>
    @endif
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
           
           
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Location</th>
                <th width="280px">Action</th>
            </tr>
            </thead>
            <tbody>
            
           
            <!-- <?php  $no=1; ?>  -->
            @foreach($cruds as $crud)

                <tr>
                    <!-- <tr class="crud{{$crud->id}}">  -->
                    <!-- <td>{{ $no++ }}</td> -->
                    <td>{{$crud->id}}</td>
                    <td>{{$crud->name}}</td>
                    <td>{{$crud->location}}</td>
                    <td>
                        <form action="{{route('cruds.destroy',$crud->id)}}" method="post" role="form">
                            <a href="{{route('cruds.show',$crud->id)}}" class="btn btn-info">Show</a>
                            <a href="{{route('cruds.edit',$crud->id)}}" class="btn btn-primary">Edit</a>
                            <input type="hidden" name="_token" value="{{csrf_token()}}">
                            <input type="hidden" name="_method" value="DELETE">
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>


                    </td>
                </tr>
            @endforeach

            </tbody>
        </table>
        {{$cruds->links()}}
    </div>

@endsection