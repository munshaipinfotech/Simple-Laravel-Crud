<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb" style="margin-top: 20px;">
            <div class="pull-left">
                <h2>Edit Record</h2>
            </div>
            <div class="pull-right">
                <a href="<?php echo e(route('cruds.index')); ?>" class="btn btn-primary">Back</a>
            </div>
        </div>
    </div>
    <br>
    <form action="<?php echo e(route('cruds.update',$crud->id)); ?>" method="post" role="form">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" name="_method" value="PUT">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group<?php echo e($errors->has('name')?' has-error':''); ?>">
                    <strong>Name:</strong>
                    <input type="text" name="name" value="<?php echo e($crud->name); ?>" class="form-control" placeholder="Name">
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group<?php echo e($errors->has('detail')?' has-error':''); ?>">
                    <strong>Location:</strong>
                    <input type="text" name="location" value="<?php echo e($crud->location); ?>" class="form-control" placeholder="Location">
                    <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cruds.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\crud\resources\views/cruds/edit.blade.php ENDPATH**/ ?>