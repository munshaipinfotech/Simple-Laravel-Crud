<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb" style="margin-top: 20px;">
            <div class="pull-left">
                <h2>Laravel 5.7 CRUD Test</h2>
            </div>
            <div class="pull-right">
                <a href="<?php echo e(route('cruds.create')); ?>" class="btn btn-success">Create New Record</a>
            </div>
        </div>
    </div>
    <?php if($message=Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
           
           
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Location</th>
                <th width="280px">Action</th>
            </tr>
            </thead>
            <tbody>
            
           
            <!-- <?php  $no=1; ?>  -->
            <?php $__currentLoopData = $cruds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <!-- <tr class="crud<?php echo e($crud->id); ?>">  -->
                    <!-- <td><?php echo e($no++); ?></td> -->
                    <td><?php echo e($crud->id); ?></td>
                    <td><?php echo e($crud->name); ?></td>
                    <td><?php echo e($crud->location); ?></td>
                    <td>
                        <form action="<?php echo e(route('cruds.destroy',$crud->id)); ?>" method="post" role="form">
                            <a href="<?php echo e(route('cruds.show',$crud->id)); ?>" class="btn btn-info">Show</a>
                            <a href="<?php echo e(route('cruds.edit',$crud->id)); ?>" class="btn btn-primary">Edit</a>
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="_method" value="DELETE">
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>


                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
        <?php echo e($cruds->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cruds.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\crud\resources\views/cruds/index.blade.php ENDPATH**/ ?>