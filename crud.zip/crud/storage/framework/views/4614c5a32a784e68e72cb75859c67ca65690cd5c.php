<?php $__env->startSection( 'content' ); ?>
    <h2>Login</h2>
    <form action="<?php echo e(url( '/login' )); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email">
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary" >Login</button>
        </div>
    </form>
    <?php echo $__env->make( 'layouts.errors' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make( 'layouts.master' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\crud\resources\views/sessions/create.blade.php ENDPATH**/ ?>