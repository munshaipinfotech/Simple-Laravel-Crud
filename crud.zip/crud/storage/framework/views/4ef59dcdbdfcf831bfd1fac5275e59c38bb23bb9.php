<div class="alert alert-error">
    <ul>
        <?php if( count( $errors ) ): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="alert-info"><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ul>
</div><?php /**PATH D:\xampp\htdocs\laravel\crud\resources\views/layouts/errors.blade.php ENDPATH**/ ?>