<div class="blog-masthead">
    <div class="container">
        <nav class="nav blog-nav">
            <a class="nav-link active" href="<?php echo e(url('/', $parameters = [], $secure = null)); ?>">Home</a>
            
            <?php if( Auth::check() ): ?>
            <a class="nav-link ml-auto" href="<?php echo e(url( '/posts' )); ?>">Welcome <?php echo e(Auth::user()->name); ?> !</a>
            <a class="nav-link" href="<?php echo e(url( '/logout' )); ?>">Logout</a>
            <?php else: ?>
                <a class="nav-link ml-auto" href="<?php echo e(url( '/register' )); ?>">Register</a>
                <a class="nav-link ml-auto" href="<?php echo e(url( '/login' )); ?>">Sign In</a>
            <?php endif; ?>
        </nav>
    </div>
</div><?php /**PATH D:\xampp\htdocs\laravel\crud\resources\views/layouts/nav.blade.php ENDPATH**/ ?>