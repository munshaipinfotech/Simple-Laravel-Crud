<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb" style="margin-top: 20px;">
            <div class="pull-left">
                <h2>Laravel 5.7 CRUD Example</h2>
            </div>
            <div class="pull-right">
                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-success">Create New Products</a>
            </div>
        </div>
    </div>
    <?php if($message=Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Details</th>
                <th width="280px">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->detail); ?></td>
                    <td>
                        <form action="<?php echo e(route('products.destroy',$product->id)); ?>" method="post" role="form">
                            <a href="<?php echo e(route('products.show',$product->id)); ?>" class="btn btn-info">Show</a>
                            <a href="<?php echo e(route('products.edit',$product->id)); ?>" class="btn btn-primary">Edit</a>
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="_method" value="DELETE">
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>


                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('products.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\crud\resources\views/products/index.blade.php ENDPATH**/ ?>