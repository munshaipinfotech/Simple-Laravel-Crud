<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb" style="margin-top: 20px;">
            <div class="pull-left">
                <h2>Add New Record</h2>
            </div>
            <div class="pull-right">
                <a href="<?php echo e(route('cruds.index')); ?>" class="btn btn-primary">Back</a>
            </div>
        </div>
    </div>
    <form action="<?php echo e(route('cruds.store')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group<?php echo e($errors->has('name')?' has-error':''); ?>">
                    <strong>Name:</strong>
                    <input type="text" name="name" class="form-control" placeholder="Name">
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group<?php echo e($errors->has('location')?' has-error':''); ?>">
                    <strong>Location:</strong>
                    <input type="text" name="location" class="form-control" placeholder="location">
                    <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <button type="submit" class="btn btn-primary">Add New</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cruds.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\crud\resources\views/cruds/create.blade.php ENDPATH**/ ?>